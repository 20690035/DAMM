import 'package:flutter/material.dart';
import 'dart:math';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);
  
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Pig',
      theme: ThemeData(
        primarySwatch: Colors.deepPurple,
      ),
      home: const MyHomePage(title: 'El juego del Pig🐷', textAlign: TextAlign.center,),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({Key? key, required this.title, required TextAlign textAlign}) : super(key: key);

  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  int _currentPlayer = 1;
  int _sum1 = 0;
  int _sum2 = 0;
  int _currentRoll = 0;
  int _savedScore1 = 0;
  int _savedScore2 = 0;

  void _rollDice() {
    setState(() {
      _currentRoll = Random().nextInt(6) + 1;

      if (_currentRoll == 1) {
        if (_currentPlayer == 1) {
          _sum1 = 0;
          _currentPlayer = 2;
        } else {
          _sum2 = 0;
          _currentPlayer = 1;
        }
      } else {
        if (_currentPlayer == 1) {
          _sum1 += _currentRoll;
        } else {
          _sum2 += _currentRoll;
        }
      }
      _checkVictory();
    });
  }

  void _saveScore() {
    setState(() {
      if (_currentPlayer == 1) {
        _savedScore1 += _sum1;
        _sum1 = 0;
      } else {
        _savedScore2 += _sum2;
        _sum2 = 0;
      }
      _currentPlayer = (_currentPlayer == 1) ? 2 : 1;

      _checkVictory();
    });
  }

  void _checkVictory() {
    // ganador
    if (_savedScore1 >= 100) {
      _showVictoryDialog(1);
    } else if (_savedScore2 >= 100) {
      _showVictoryDialog(2);
    }
  }

  void _showVictoryDialog(int winner) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('¡Felicidades! El jugador $winner ha ganado.'),
          actions: <Widget>[
            TextButton(
              onPressed: () {
                setState(() {
                  _sum1 = 0;
                  _sum2 = 0;
                  _savedScore1 = 0;
                  _savedScore2 = 0;
                  _currentPlayer = 1;
                });
                Navigator.of(context).pop();
              },
              child: const Text('Volver a jugar'),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Text(
              'Turno del Jugador $_currentPlayer',
              style: const TextStyle(fontSize: 20),
            ),
            const Text(
              'Suma de los tiros:',
              style: TextStyle(fontSize: 20),
            ),
            Text(
              '${(_currentPlayer == 1) ? _sum1 : _sum2}',
              style: const TextStyle(fontSize: 36, fontWeight: FontWeight.bold),
            ),
            if (_currentRoll != 0)
              Text(
                'Resultado del dado: $_currentRoll',
                style: const TextStyle(fontSize: 20),
              ),
            const SizedBox(height: 30),
            ElevatedButton(
              onPressed: _rollDice,
              child: const Padding(
                padding: EdgeInsets.all(16.0),
                child: Text(
                  '🎲',
                  style: TextStyle(fontSize: 20),
                ),
              ),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: _saveScore,
              child: const Padding(
                padding: EdgeInsets.all(16.0),
                child: Text(
                  'Guardar puntaje',
                  style: TextStyle(fontSize: 20),
                ),
              ),
            ),
            const SizedBox(height: 30),
            const Text(
              'Resultados Guardados:',
              style: TextStyle(fontSize: 20),
            ),
            Text(
              'Jugador 1: $_savedScore1',
              style: const TextStyle(fontSize: 18),
            ),
            Text(
              'Jugador 2: $_savedScore2',
              style: const TextStyle(fontSize: 18),
            ),
          ],
        ),
      ),
    );
  }
}