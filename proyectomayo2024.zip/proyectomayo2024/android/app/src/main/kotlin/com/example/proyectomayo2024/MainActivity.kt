package com.example.proyectomayo2024

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
